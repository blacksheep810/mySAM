# 表现差样本检测功能说明

## 功能概述

这个功能用于**在训练过程中实时**识别mIoU表现差的样本，并将这些样本单独存储，同时生成包含大小框和mask的可视化图像。与训练后检测不同，这个功能会在每个batch训练时实时检测，帮助您了解模型在不同训练阶段的性能表现。

## 文件说明

### 1. `training/trainer.py` (已修改)
训练器主文件，已集成表现差样本检测功能。

**主要功能：**
- 在训练过程中实时计算每个样本的IoU
- 识别IoU低于阈值的样本
- 实时保存可视化图像和CSV文件
- 按epoch组织输出结果

### 2. `train_with_poor_sample_detection.py` (可选)
独立的检测脚本，用于训练后检测表现差的样本（如果需要单独运行）。

### 2. `utils/metrics.py`
新增函数：`compute_iou_per_sample()`
- 计算每个样本的IoU值（返回tensor，而不是平均值）

### 3. `utils/visualization.py`
新增函数：`visualize_prediction_with_boxes()`
- 可视化预测结果，包含：
  - 原始图像
  - 大框（红色）
  - 小框（绿色）
  - 预测mask（绿色半透明覆盖）
  - 真实mask（蓝色轮廓）
  - IoU值和图像名称

## 使用方法

### 在训练过程中启用检测（推荐）

在训练命令中添加以下参数：

```bash
python train.py \
  --data_root ./data/ISIC \
  --train_box_csv ./data/ISIC/train_boxes_update.csv \
  --sam_checkpoint ./checkpoints/sam_vit_h_4b8939.pth \
  --model_type vit_h \
  --output_dir ./outputs_huge_with_poor_detection \
  --batch_size 4 \
  --epochs 30 \
  --img_size 1024 \
  --device cuda \
  --detect_poor_samples \
  --poor_sample_iou_threshold_severe 0.75 \
  --poor_sample_iou_threshold_moderate 0.8 \
  --poor_sample_save_interval 1
```

**或使用提供的shell脚本：**

```bash
bash train_with_poor_detection.sh
```

### 训练后检测（可选）

如果需要单独检测训练后的模型：

```bash
python train_with_poor_sample_detection.py \
  --data_root ./data/ISIC \
  --train_box_csv ./data/ISIC/train_boxes_update.csv \
  --sam_checkpoint ./checkpoints/sam_vit_h_4b8939.pth \
  --model_type vit_h \
  --output_dir ./outputs_poor_samples \
  --batch_size 4 \
  --img_size 1024 \
  --iou_threshold 0.5 \
  --device cuda
```

### 使用训练后的模型

如果需要使用训练后的模型，添加 `--checkpoint_path` 参数：

```bash
python train_with_poor_sample_detection.py \
  --data_root ./data/ISIC \
  --train_box_csv ./data/ISIC/train_boxes_update.csv \
  --sam_checkpoint ./checkpoints/sam_vit_h_4b8939.pth \
  --model_type vit_h \
  --output_dir ./outputs_poor_samples \
  --batch_size 4 \
  --img_size 1024 \
  --iou_threshold 0.5 \
  --checkpoint_path ./outputs_huge_update_optimized/checkpoint_epoch_30.pth \
  --device cuda
```

### 使用提供的shell脚本

```bash
bash detect_poor_samples.sh
```

## 参数说明

### 必需参数
- `--data_root`: ISIC数据集根目录
- `--train_box_csv`: 训练集box CSV文件路径
- `--sam_checkpoint`: SAM模型checkpoint路径
- `--model_type`: SAM模型类型（vit_b, vit_l, vit_h）

### 训练时检测参数（新增）
- `--detect_poor_samples`: 启用训练过程中的表现差样本检测（action='store_true'）
- `--poor_sample_iou_threshold_severe`: 严重样本阈值，IoU低于此值的样本为严重问题（默认: 0.75）
- `--poor_sample_iou_threshold_moderate`: 中等样本阈值上限，IoU在此范围内的样本为中等问题（默认: 0.8）
- `--poor_sample_save_interval`: 每N个epoch保存一次表现差样本（默认: 1）

### 其他可选参数
- `--output_dir`: 输出目录（默认: ./outputs）
- `--batch_size`: 批次大小（默认: 4）
- `--img_size`: 图像尺寸（默认: 1024）
- `--device`: 设备（默认: cuda）

## 输出结果

### 训练时检测的输出结构

训练过程中会在 `output_dir` 目录下创建以下结构：

```
outputs_huge_with_poor_detection/
├── poor_samples_epoch_1/          # 第1个epoch的表现差样本
│   └── visualization/             # 可视化图像目录
│       ├── severe/                # 严重问题样本 (IoU < 0.75)
│       │   ├── ISIC_0000410_iou0.3245.jpg
│       │   └── ...
│       └── moderate/              # 中等问题样本 (0.75 ≤ IoU < 0.8)
│           ├── ISIC_0000548_iou0.7654.jpg
│           └── ...
├── poor_samples_epoch_2/          # 第2个epoch的表现差样本
│   └── visualization/
│       ├── severe/
│       └── moderate/
├── poor_samples_csv/               # CSV文件目录
│   ├── poor_samples_all_epochs.csv    # 所有epoch的表现差样本汇总（包含severity列）
│   ├── poor_samples_epoch_1.csv       # 第1个epoch的表现差样本
│   ├── poor_samples_epoch_2.csv       # 第2个epoch的表现差样本
│   └── ...
└── checkpoint_epoch_*.pth         # 训练checkpoint
```

### CSV文件格式

`poor_samples_epoch_N.csv` 和 `poor_samples_all_epochs.csv` 包含以下列：
- `epoch`: 训练epoch编号
- `iteration`: 训练iteration编号
- `image_file`: 图像文件名
- `iou`: IoU值
- `severity`: 严重程度（`severe` 或 `moderate`）
- `big_box_x1`, `big_box_y1`, `big_box_x2`, `big_box_y2`: 大框坐标
- `small_box_x1`, `small_box_y1`, `small_box_x2`, `small_box_y2`: 小框坐标（如果存在）

### 可视化图像说明

每张可视化图像包含：
- **红色框**: 大框（Big Box）
- **绿色框**: 小框（Small Box）
- **绿色半透明覆盖**: 预测mask
- **蓝色轮廓**: 真实mask（Ground Truth）
- **文本信息**: 图像名称和IoU值

## 示例

参考 `utils/test/box_validation/invalid_boxes/ISIC_0000410.jpg` 可以看到类似的可视化效果。

## 注意事项

1. 确保有足够的磁盘空间存储可视化图像
2. 如果数据集很大，建议使用较小的 `batch_size` 以避免显存不足
3. **IoU阈值分级标准**（已实现多级分类）：
   - **IoU < 0.75**: 严重问题样本（severe）- 需要重点关注
   - **0.75 ≤ IoU < 0.8**: 中等问题样本（moderate）- 可以改进
   - **IoU ≥ 0.8**: 合理样本 - 不保存
   
   可以通过参数调整阈值：
   - `--poor_sample_iou_threshold_severe`: 严重阈值（默认0.75）
   - `--poor_sample_iou_threshold_moderate`: 中等阈值上限（默认0.8）

## 工作原理

### 训练时检测流程

1. **实时计算**: 在每个batch训练时，计算每个样本的IoU值
2. **阈值判断**: 如果样本IoU低于设定阈值，立即保存可视化结果
3. **按epoch组织**: 每个epoch的表现差样本保存在独立的目录中
4. **CSV汇总**: 同时保存每个epoch的CSV文件和所有epoch的汇总CSV

### 优势

- **实时监控**: 可以实时了解模型在不同训练阶段的性能
- **问题定位**: 快速发现哪些样本一直表现不好，可能是数据质量问题
- **训练分析**: 通过对比不同epoch的表现差样本，了解模型改进情况
- **无需额外时间**: 检测过程在训练循环中完成，不增加额外训练时间

## 注意事项

1. **性能影响**: 启用检测功能会增加少量计算开销（主要是IoU计算和可视化保存）
2. **磁盘空间**: 确保有足够的磁盘空间存储可视化图像
3. **IO开销**: 频繁保存图像可能影响训练速度，建议适当调整 `poor_sample_save_interval`
4. **阈值设置**: `poor_sample_iou_threshold` 可以根据实际需求调整：
   - 0.3: 非常差的样本（用于发现严重问题）
   - 0.5: 中等偏下的样本（默认值，平衡检测范围）
   - 0.7: 较好的样本（用于筛选高质量样本）
